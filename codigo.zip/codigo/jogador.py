import pygame
from tela import Tela

class Jogador(pygame.sprite.Sprite):
    def __init__(self, group, tela : Tela):
        super().__init__(group)
        self.__tela = tela
        self.__frames = [
            pygame.image.load(rf'C:\GitHub\Jogo\imagens\nave0.png').convert_alpha(),
            pygame.image.load(rf'C:\GitHub\Jogo\imagens\nave1.png').convert_alpha(),
            pygame.image.load(rf'C:\GitHub\Jogo\imagens\nave2.png').convert_alpha(),
            pygame.image.load(rf'C:\GitHub\Jogo\imagens\nave3.png').convert_alpha(),
            pygame.image.load(rf'C:\GitHub\Jogo\imagens\nave4.png').convert_alpha()
        ]
        self.__indice = 0
        self.__image = self.__frames[self.__indice]
        self.__rect = self.__image.get_rect(center = (400, 400))
        self.__tempo_animacao = 5 
        self.__contador = 0
        self.__vento = pygame.image.load(fr'C:\GitHub\Jogo\imagens\vento.png').convert_alpha()
        self.__vento_rect = self.__vento.get_rect(center = (self.__rect.center))
        self.__subindo = False

    @property
    def tela(self):
        return self.__tela

    @tela.setter
    def tela(self, value):
        self.__tela = value

    @property
    def frames(self):
        return self.__frames

    @frames.setter
    def frames(self, value):
        self.__frames = value

    @property
    def indice(self):
        return self.__indice

    @indice.setter
    def indice(self, value):
        self.__indice = value
    
    @property
    def image(self):
        return self.__image
    
    @image.setter
    def image(self, value):
        self.__image = value

    @property
    def rect(self):
        return self.__rect

    @rect.setter 
    def rect(self, value):
        self.__rect = value

    @property
    def tempo_animacao(self):
        return self.__tempo_animacao

    @tempo_animacao.setter
    def tempo_animacao(self, value):
        self.__tempo_animacao = value

    @property
    def contador(self):
        return self.__contador

    @contador.setter
    def contador(self, value):
        self.__contador = value

    def animacao_vento(self):
        if self.__subindo:
            self.__vento_rect.centerx = self.rect.centerx - 1
            self.__vento_rect.centery = self.rect.centery
            self.tela.display.blit(self.__vento, self.__vento_rect)
        
    def update(self):
      tecla = pygame.key.get_pressed()
      moveu = False

      # Animação
      self.contador += 1
      if self.contador >= self.tempo_animacao:
        self.contador = 0
        self.indice = (self.indice + 1) % len(self.frames)
        self.image = self.frames[self.indice]
    

      if tecla[pygame.K_RIGHT] or tecla[pygame.K_d]:
        if self.rect.right < self.tela.largura:
           self.rect.right += 5
           self.__subindo = False
           moveu = True

      if tecla[pygame.K_LEFT] or tecla[pygame.K_a]:
        if self.rect.left > 0:
           self.rect.left -= 5
           self.__subindo = False
           moveu = True
    
      if tecla[pygame.K_UP] or tecla[pygame.K_w]:
        if self.rect.top > 0 :
           self.rect.top -= 2
           self.__subindo = True
           moveu = True

      if tecla[pygame.K_DOWN] or tecla[pygame.K_s]:
        if self.rect.bottom < self.tela.altura:
           self.rect.bottom += 5
           self.__subindo = False
           moveu = True
      
      if not moveu:
        if self.rect.bottom < self.tela.altura:
           self.rect.bottom += 1
           self.__subindo = False

           
      