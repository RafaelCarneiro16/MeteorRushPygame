import pygame
from texto import Texto

class PowerUp(pygame.sprite.Sprite):
    def __init__(self, tipo, grupo, posicao, tela, jogador): 
        super().__init__(grupo)
        self.tipo = tipo
        self.tela = tela
        self.jogador = jogador
        
        self.power_up_image = pygame.image.load(f'C:/GitHub/Jogo/imagens/power_up.png').convert_alpha() 
        self.escudo_image = pygame.image.load(r'C:\GitHub\Jogo\imagens\escudo.png').convert_alpha()
        
        if tipo == 'power_up':
            self.image = self.power_up_image
            self.rect = self.image.get_rect(center=posicao)

        elif tipo == 'escudo':
            self.image = self.escudo_image
            self.rect = self.image.get_rect(center=self.jogador.rect.center) 
            self.tempo_ativado = pygame.time.get_ticks() 
            self.duracao = 8000

    def update(self): 
        if self.tipo == 'power_up':
            self.rect.y += 2
            if self.rect.top > self.tela.altura: 
                self.kill()

        elif self.tipo == 'escudo':
            self.rect.center = self.jogador.rect.center 
            tempo_atual = pygame.time.get_ticks()
        
            if tempo_atual - self.tempo_ativado > self.duracao:
                self.kill()

    def desenhar_temporizador(self):
        if self.tipo == 'escudo':
            tempo_atual = pygame.time.get_ticks()
            tempo_restante = max(0,self.duracao-(tempo_atual - self.tempo_ativado)) // 1000
            
            texto = Texto(24, f'Escudo: {tempo_restante}', (255, 255, 255), (740, 580), self.tela)
            texto.desenha_texto()